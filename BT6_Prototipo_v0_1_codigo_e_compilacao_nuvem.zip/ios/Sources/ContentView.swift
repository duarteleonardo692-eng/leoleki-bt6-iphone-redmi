import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var bridge: BT6PeripheralBridge

    var body: some View {
        NavigationStack {
            Form {
                Section("Ponte Bluetooth BT6 — etapa 1") {
                    Text("Teste direto iPhone XR → Redmi Note 11, sem PC durante a comunicacao.")
                        .font(.subheadline)
                    LabeledContent("Bluetooth", value: bridge.bluetoothStatus)
                    LabeledContent("Servidor BLE", value: bridge.serverStatus)
                    LabeledContent("Redmi", value: bridge.clientStatus)
                    Button("Reiniciar anuncio BLE") {
                        bridge.restartAdvertising()
                    }
                }

                Section("Diagnostico") {
                    Text("Ultimo pedido: \(bridge.lastRequest)")
                    Text("Ultima resposta: \(bridge.lastResponse)")
                    Text("Deixe este app aberto e o iPhone conectado ao Wi-Fi durante os testes.")
                        .font(.footnote)
                }

                Section("O que esta versao faz") {
                    Text("Responde a um PING Bluetooth e busca https://example.com usando a internet do iPhone. Envia apenas um resumo do resultado ao Redmi.")
                    Text("Ainda NAO entrega internet geral para os aplicativos do Android. Isso exige a proxima etapa: VPN local, proxy e transporte continuo de dados.")
                        .font(.footnote)
                }
            }
            .navigationTitle("BT6 iPhone")
        }
    }
}
