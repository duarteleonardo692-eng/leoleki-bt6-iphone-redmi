import Foundation
import CoreBluetooth
import Combine

final class BT6PeripheralBridge: NSObject, ObservableObject, CBPeripheralManagerDelegate {
    // Os mesmos UUIDs precisam aparecer no app Android.
    static let serviceUUID = CBUUID(string: "AD08C143-7581-4612-9D63-20D9540C4A01")
    static let requestUUID = CBUUID(string: "AD08C143-7581-4612-9D63-20D9540C4A02")
    static let responseUUID = CBUUID(string: "AD08C143-7581-4612-9D63-20D9540C4A03")

    @Published private(set) var bluetoothStatus = "Verificando"
    @Published private(set) var serverStatus = "Aguardando"
    @Published private(set) var clientStatus = "Aguardando Redmi"
    @Published private(set) var lastRequest = "Nenhum"
    @Published private(set) var lastResponse = "Nenhuma"

    private var manager: CBPeripheralManager!
    private var requestCharacteristic: CBMutableCharacteristic?
    private var responseCharacteristic: CBMutableCharacteristic?
    private var readyToNotify = false
    private var queuedPackets: [Data] = []

    override init() {
        super.init()
        manager = CBPeripheralManager(delegate: self, queue: .main)
    }

    func peripheralManagerDidUpdateState(_ peripheral: CBPeripheralManager) {
        switch peripheral.state {
        case .poweredOn:
            bluetoothStatus = "Ligado"
            createService()
        case .poweredOff:
            bluetoothStatus = "Desligado"
            serverStatus = "Ative o Bluetooth"
            readyToNotify = false
        case .unauthorized:
            bluetoothStatus = "Sem permissao"
            serverStatus = "Autorize Bluetooth nos Ajustes"
        case .unsupported:
            bluetoothStatus = "Nao suportado"
        default:
            bluetoothStatus = "Aguardando"
        }
    }

    private func createService() {
        manager.stopAdvertising()
        manager.removeAllServices()
        readyToNotify = false
        queuedPackets.removeAll()

        let request = CBMutableCharacteristic(type: Self.requestUUID,
                                               properties: [.write],
                                               value: nil,
                                               permissions: [.writeable])
        let response = CBMutableCharacteristic(type: Self.responseUUID,
                                                properties: [.notify],
                                                value: nil,
                                                permissions: [])
        requestCharacteristic = request
        responseCharacteristic = response
        let service = CBMutableService(type: Self.serviceUUID, primary: true)
        service.characteristics = [request, response]
        manager.add(service)
        serverStatus = "Configurando servico"
    }

    func peripheralManager(_ peripheral: CBPeripheralManager, didAdd service: CBService, error: Error?) {
        if let error {
            serverStatus = "Falha no servico: \(error.localizedDescription)"
            return
        }
        peripheral.startAdvertising([
            CBAdvertisementDataServiceUUIDsKey: [Self.serviceUUID],
            CBAdvertisementDataLocalNameKey: "BT6-LEOLEKI"
        ])
    }

    func peripheralManagerDidStartAdvertising(_ peripheral: CBPeripheralManager, error: Error?) {
        if let error {
            serverStatus = "Erro no anuncio: \(error.localizedDescription)"
        } else {
            serverStatus = "Anunciando BT6"
        }
    }

    func restartAdvertising() {
        guard manager.state == .poweredOn else {
            serverStatus = "Bluetooth indisponivel"
            return
        }
        createService()
    }

    func peripheralManager(_ peripheral: CBPeripheralManager,
                           central: CBCentral,
                           didSubscribeTo characteristic: CBCharacteristic) {
        guard characteristic.uuid == Self.responseUUID else { return }
        readyToNotify = true
        clientStatus = "Redmi conectado (notificacoes BLE)"
        flushPackets()
    }

    func peripheralManager(_ peripheral: CBPeripheralManager,
                           central: CBCentral,
                           didUnsubscribeFrom characteristic: CBCharacteristic) {
        guard characteristic.uuid == Self.responseUUID else { return }
        readyToNotify = false
        queuedPackets.removeAll()
        clientStatus = "Redmi desconectado"
    }

    func peripheralManager(_ peripheral: CBPeripheralManager,
                           didReceiveWrite requests: [CBATTRequest]) {
        for request in requests {
            guard request.characteristic.uuid == Self.requestUUID,
                  request.offset == 0,
                  let value = request.value,
                  value.count == 1 else {
                peripheral.respond(to: request, withResult: .invalidAttributeValueLength)
                continue
            }
            peripheral.respond(to: request, withResult: .success)
            switch value[0] {
            case 0x50: // 'P' de PING
                lastRequest = "PING"
                sendResponse("PONG | iPhone recebeu o pedido Bluetooth")
            case 0x47: // 'G': GET fixo, sem abrir um proxy publico
                lastRequest = "GET https://example.com"
                testWiFiRequest()
            default:
                lastRequest = "Comando desconhecido"
                sendResponse("ERRO | comando nao reconhecido")
            }
        }
    }

    private func testWiFiRequest() {
        guard let url = URL(string: "https://example.com") else { return }
        var request = URLRequest(url: url)
        request.timeoutInterval = 12
        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                guard let self else { return }
                if let error {
                    self.sendResponse("ERRO INTERNET | \(error.localizedDescription)")
                    return
                }
                let code = (response as? HTTPURLResponse)?.statusCode ?? 0
                let title = String(data: data ?? Data(), encoding: .utf8)?
                    .replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
                    .prefix(180) ?? Substring("")
                self.sendResponse("HTTP \(code) | \(title)")
            }
        }.resume()
    }

    private func sendResponse(_ message: String) {
        lastResponse = String(message.prefix(150))
        guard readyToNotify, responseCharacteristic != nil else {
            serverStatus = "Sem assinatura BLE para resposta"
            return
        }
        // Cada pacote tem no maximo 18 bytes para funcionar com MTU BLE minimo.
        // 0x01 inicia, 0x02 carrega dados, 0x03 encerra.
        queuedPackets = [Data([0x01])]
        let bytes = Array(message.utf8.prefix(800))
        var cursor = 0
        while cursor < bytes.count {
            let end = min(cursor + 17, bytes.count)
            queuedPackets.append(Data([0x02] + Array(bytes[cursor..<end])))
            cursor = end
        }
        queuedPackets.append(Data([0x03]))
        flushPackets()
    }

    private func flushPackets() {
        guard readyToNotify, let responseCharacteristic else { return }
        while let packet = queuedPackets.first {
            guard manager.updateValue(packet,
                                      for: responseCharacteristic,
                                      onSubscribedCentrals: nil) else { return }
            queuedPackets.removeFirst()
        }
    }

    func peripheralManagerIsReady(toUpdateSubscribers peripheral: CBPeripheralManager) {
        flushPackets()
    }
}
