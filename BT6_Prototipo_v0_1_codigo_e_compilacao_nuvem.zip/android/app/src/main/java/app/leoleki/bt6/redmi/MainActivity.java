package app.leoleki.bt6.redmi;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final UUID SERVICE = UUID.fromString("AD08C143-7581-4612-9D63-20D9540C4A01");
    private static final UUID REQUEST = UUID.fromString("AD08C143-7581-4612-9D63-20D9540C4A02");
    private static final UUID RESPONSE = UUID.fromString("AD08C143-7581-4612-9D63-20D9540C4A03");
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805F9B34FB");
    private static final int REQ_BT_PERMISSIONS = 901;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ByteArrayOutputStream responseBuffer = new ByteArrayOutputStream();
    private TextView status;
    private TextView log;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic requestChar;
    private BluetoothGattCharacteristic responseChar;
    private boolean scanning;
    private boolean notificationReady;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setPadding(32, 40, 32, 32);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        TextView title = new TextView(this);
        title.setText("BT6 — Redmi Note 11");
        title.setTextSize(24f);
        content.addView(title);
        TextView description = new TextView(this);
        description.setText("Etapa 1: verificar Bluetooth BLE e um teste de acesso a internet feito pelo iPhone. Sem VPN ainda.");
        description.setTextSize(15f);
        content.addView(description);
        status = new TextView(this);
        status.setTextSize(18f);
        status.setText("Status: pronto para procurar iPhone");
        content.addView(status);
        Button scan = new Button(this);
        scan.setText("1. Buscar iPhone BT6");
        scan.setOnClickListener(v -> ensurePermissionsAndScan());
        content.addView(scan);
        Button ping = new Button(this);
        ping.setText("2. Testar Bluetooth (PING)");
        ping.setOnClickListener(v -> send((byte) 0x50));
        content.addView(ping);
        Button get = new Button(this);
        get.setText("3. Testar internet do iPhone");
        get.setOnClickListener(v -> send((byte) 0x47));
        content.addView(get);
        log = new TextView(this);
        log.setTextSize(14f);
        log.setText("Registro do teste:\n");
        content.addView(log);
        setContentView(scroll);
    }

    private void status(String text) {
        runOnUiThread(() -> { status.setText("Status: " + text); log.append(text + "\n"); });
    }

    private boolean hasPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void ensurePermissionsAndScan() {
        if (!hasPermissions()) {
            if (Build.VERSION.SDK_INT >= 31) {
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT_PERMISSIONS);
            } else {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_BT_PERMISSIONS);
            }
            return;
        }
        startScan();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (requestCode == REQ_BT_PERMISSIONS) {
            if (hasPermissions()) startScan(); else status("Permissao Bluetooth negada");
        }
    }

    @SuppressLint("MissingPermission")
    private void startScan() {
        BluetoothManager btManager = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        BluetoothAdapter adapter = btManager == null ? null : btManager.getAdapter();
        if (adapter == null || !adapter.isEnabled()) {
            status("Ative o Bluetooth do Redmi primeiro");
            return;
        }
        stopScan();
        if (gatt != null) { gatt.close(); gatt = null; }
        requestChar = null;
        responseChar = null;
        notificationReady = false;
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) { status("Scanner BLE indisponivel"); return; }
        ScanFilter filter = new ScanFilter.Builder().setServiceUuid(new ParcelUuid(SERVICE)).build();
        List<ScanFilter> filters = Arrays.asList(filter);
        ScanSettings settings = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
        scanning = true;
        scanner.startScan(filters, settings, callback);
        status("Procurando anuncio BT6 no iPhone (abra o app no iPhone)");
        handler.postDelayed(() -> {
            if (scanning) { stopScan(); status("Tempo esgotado. Tente novamente com o app do iPhone aberto."); }
        }, 20000);
    }

    @SuppressLint("MissingPermission")
    private void stopScan() {
        if (scanning && scanner != null) scanner.stopScan(callback);
        scanning = false;
    }

    private final ScanCallback callback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            if (!scanning || result.getDevice() == null) return;
            BluetoothDevice device = result.getDevice();
            stopScan();
            status("BT6 encontrado. Conectando...");
            connect(device);
        }
        @Override public void onScanFailed(int errorCode) { scanning = false; status("Erro de busca BLE: " + errorCode); }
    };

    @SuppressLint("MissingPermission")
    private void connect(BluetoothDevice device) {
        gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt connection, int code, int newState) {
            if (code != BluetoothGatt.GATT_SUCCESS) {
                notificationReady = false;
                status("Falha GATT: " + code);
                return;
            }
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                status("Bluetooth conectado. Lendo servicos...");
                discover(connection);
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                notificationReady = false;
                status("iPhone desconectado");
            }
        }

        @Override public void onServicesDiscovered(BluetoothGatt connection, int code) {
            if (code != BluetoothGatt.GATT_SUCCESS) { status("Erro ao encontrar servicos: " + code); return; }
            BluetoothGattService service = connection.getService(SERVICE);
            if (service == null) { status("Servico BT6 nao encontrado"); return; }
            requestChar = service.getCharacteristic(REQUEST);
            responseChar = service.getCharacteristic(RESPONSE);
            if (requestChar == null || responseChar == null) { status("Caracteristicas BT6 ausentes"); return; }
            enableNotifications(connection);
        }

        @Override public void onDescriptorWrite(BluetoothGatt connection, BluetoothGattDescriptor descriptor, int code) {
            if (CCCD.equals(descriptor.getUuid()) && code == BluetoothGatt.GATT_SUCCESS) {
                notificationReady = true;
                status("Conectado. Toque em Testar Bluetooth (PING).");
            } else status("Falha ao ativar notificacoes BLE: " + code);
        }
        @Override public void onCharacteristicWrite(BluetoothGatt connection, BluetoothGattCharacteristic characteristic, int code) {
            if (code != BluetoothGatt.GATT_SUCCESS) status("Falha ao enviar comando: " + code);
        }
        @Override public void onCharacteristicChanged(BluetoothGatt connection, BluetoothGattCharacteristic ch) {
            parseNotification(ch.getValue());
        }
        @Override public void onCharacteristicChanged(BluetoothGatt connection, BluetoothGattCharacteristic ch, byte[] value) {
            parseNotification(value);
        }
    };

    @SuppressLint("MissingPermission")
    private void discover(BluetoothGatt connection) { connection.discoverServices(); }

    @SuppressLint("MissingPermission")
    private void enableNotifications(BluetoothGatt connection) {
        if (!connection.setCharacteristicNotification(responseChar, true)) {
            status("Nao foi possivel ouvir respostas"); return;
        }
        BluetoothGattDescriptor descriptor = responseChar.getDescriptor(CCCD);
        if (descriptor == null) { status("Descritor CCCD nao encontrado"); return; }
        if (Build.VERSION.SDK_INT >= 33) {
            int result = connection.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            if (result != BluetoothGatt.GATT_SUCCESS) status("Erro ao ativar notificacao: " + result);
        } else {
            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            if (!connection.writeDescriptor(descriptor)) status("Falha ao ativar notificacao");
        }
    }

    @SuppressLint("MissingPermission")
    private void send(byte command) {
        if (gatt == null || requestChar == null || !notificationReady) {
            status("Conecte primeiro ao iPhone BT6"); return;
        }
        byte[] value = new byte[]{command};
        if (Build.VERSION.SDK_INT >= 33) {
            int result = gatt.writeCharacteristic(requestChar, value, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            if (result != BluetoothGatt.GATT_SUCCESS) status("Erro ao transmitir: " + result);
        } else {
            requestChar.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            requestChar.setValue(value);
            if (!gatt.writeCharacteristic(requestChar)) status("Falha ao transmitir");
        }
        status(command == 0x50 ? "PING enviado" : "Pedido de internet enviado ao iPhone");
    }

    private synchronized void parseNotification(byte[] packet) {
        if (packet == null || packet.length == 0) return;
        int frame = packet[0] & 0xFF;
        if (frame == 1) responseBuffer.reset();
        if (frame == 2 && packet.length > 1 && responseBuffer.size() + packet.length < 2048) {
            responseBuffer.write(packet, 1, packet.length - 1);
        }
        if (frame == 3) {
            String result = new String(responseBuffer.toByteArray(), StandardCharsets.UTF_8);
            status("Resposta do iPhone: " + result);
            responseBuffer.reset();
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        stopScan();
        if (gatt != null) { gatt.close(); gatt = null; }
    }
}
